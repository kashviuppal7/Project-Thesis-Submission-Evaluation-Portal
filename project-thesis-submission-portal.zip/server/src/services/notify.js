import nodemailer from 'nodemailer';
import { Notification } from '../models/index.js';
let transporter;
if(process.env.EMAIL_HOST)transporter=nodemailer.createTransport({host:process.env.EMAIL_HOST,port:Number(process.env.EMAIL_PORT||587),secure:Number(process.env.EMAIL_PORT)===465,auth:{user:process.env.EMAIL_USER,pass:process.env.EMAIL_PASS}});
export async function notify(user,title,message,link,type='info'){if(!user)return;const recipient=typeof user==='object'?user:await (await import('../models/index.js')).User.findById(user);if(!recipient)return;await Notification.create({user:recipient._id,title,message,link,type});if(transporter&&recipient.email)await transporter.sendMail({from:process.env.EMAIL_FROM,to:recipient.email,subject:title,text:message});}
