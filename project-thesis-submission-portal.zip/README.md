# Project / Thesis Submission & Evaluation Portal

A full-stack MERN application for managing university projects from proposal submission through evaluation and grade publication. The UI is built with React, Vite, React Router, Redux Toolkit, Recharts, and custom responsive CSS. The API uses Express, Mongoose, JWT, bcrypt, Multer, Nodemailer, and PDFKit.

## Requirements

- Node.js 20 or later and npm 10 or later
- MongoDB Community Server or a MongoDB Atlas connection string

## Local setup

1. Install dependencies from the repository root:

   ```bash
   npm install
   ```

2. Copy `server/.env.example` to `server/.env`, then set MongoDB and long random JWT secrets. Copy `client/.env.example` to `client/.env` if the API is not at `http://localhost:4000/api`.

3. Seed sample accounts, rubric, and projects:

   ```bash
   npm run seed
   ```

4. Start the API and Vite development server:

   ```bash
   npm run dev
   ```

   The client is at `http://localhost:5173`; the API is at `http://localhost:4000`.

## Demo accounts

The seed script creates all roles with password `Thesis2026!`:

| Role | Email |
| --- | --- |
| Admin / coordinator | `admin@northstar.edu` |
| Guide | `guide@northstar.edu` |
| Panel member | `panel@northstar.edu` |
| Student | `student@northstar.edu` |

Change demo passwords before using a deployed environment. The seed script clears portal collections before creating the demo dataset; do not run it against a production database.

## Project layout

```text
server/
  src/
    config/                 # Environment and database configuration extension point
    controllers/            # Auth, projects, submissions, reviews, notifications
    middleware/             # JWT roles, centralized errors
    models/index.js         # User, Project, Submission, Rubric, Evaluation,
                            # PlagiarismCheck, Notification, AuditLog
    routes/                 # Reserved for route modules as API grows
    services/               # Local storage abstraction and email notifications
    utils/                  # Async controller wrapper
  uploads/                  # Local development file store
client/
  src/
    App.jsx                 # Protected role-aware routes and app screens
    services/api.js         # Authenticated REST client
    styles.css              # Responsive interface
```

Submissions store a `storageKey` rather than a filesystem path. Replace `server/src/services/storage.js` with an S3 or Cloudinary adapter and preserve that interface to change providers.

## Workflow and scoring

```text
Draft → Proposal Submitted → Proposal Approved → Final Report Submitted
                 ↘ Revision Requested → Proposal Submitted
                 ↘ Rejected
Final Report Submitted → Under Review → Evaluated → Grade Finalized (locked)
```

Server routes validate state transitions and enforce project ownership and reviewer assignment. Proposal and final report uploads are limited by `MAX_FILE_SIZE_MB` and PDF/DOCX MIME type. Every upload creates a new version and records whether it missed the relevant deadline. Rubric weights must total 100%. Each evaluation scores every assigned criterion; the weighted score is calculated by the API. Admins set guide/panel grade weights per project (default 40/60), and the final score combines the guide score with the panel average. Grade finalization stores a locked grade and audit record. Flagged plagiarism requires an explicit admin override and reason.

## Authentication and email

Login returns a short lived access JWT and sets a rotating refresh token in an HTTP-only, same-site cookie. The browser keeps the access JWT in local storage for the demo UI. A daily reminder job checks deadlines within 72 hours at 08:00 UTC and deduplicates reminders per user/project/day. Set `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_USER`, `EMAIL_PASS`, and `EMAIL_FROM` to enable Nodemailer; otherwise notifications remain in-app. For production, use HTTPS, secure cookie settings, a managed secret store, and an appropriate client token storage strategy.

## API reference

All routes are prefixed with `/api`. Protected routes require `Authorization: Bearer <accessToken>`. `student`, `guide`, `panel`, and `admin` indicate role access; assignments and ownership are additionally checked on the server.

| Method | Route | Access | Purpose |
| --- | --- | --- | --- |
| GET | `/health` | Public | API health |
| POST | `/auth/login` | Public | Sign in, receive access token and refresh cookie |
| POST | `/auth/refresh` | Refresh cookie | Renew access token |
| POST | `/auth/logout` | Any signed-in role | Revoke refresh session |
| GET | `/auth/me` | Any signed-in role | Current account |
| GET | `/dashboard` | All roles | Role-scoped stats and status counts |
| GET | `/projects` | All roles | Role/assignment-scoped project list |
| POST | `/projects` | Student | Create a draft project |
| PATCH | `/projects/:id` | Student (own title/abstract), Admin | Edit draft metadata or assign guide/panel/rubric, deadlines and grade mix |
| POST | `/projects/:id/transition` | Assigned student/guide/panel, Admin for final transition | Validated workflow change |
| GET | `/projects/:id/submissions` | Project team | Submission and feedback history |
| POST | `/projects/:id/submissions` | Project student | Upload PDF/DOCX as a new version (`multipart/form-data`: `file`, `type`) |
| GET | `/submissions/:id/download` | Project team | Download a submission |
| POST | `/submissions/:submissionId/feedback` | Assigned guide/panel | Add a threaded comment (`body`, optional `parent`) |
| GET | `/rubrics` | Signed-in roles | List rubrics |
| POST | `/rubrics` | Admin | Create weighted rubric |
| GET | `/projects/:id/evaluations` | Project team | List reviewer scores |
| POST | `/projects/:id/evaluations` | Assigned guide/panel | Score each rubric criterion and add overall comment |
| PUT | `/projects/:id/plagiarism` | Admin, assigned guide | Set status, similarity and report URL |
| POST | `/projects/:id/finalize` | Admin | Finalize and lock grade (flagged requires `{override:true, reason}`) |
| GET | `/projects/:id/result.pdf` | Admin/team student | Download published result PDF |
| GET | `/notifications` | Signed-in roles | Current user's notifications |
| PATCH | `/notifications/:id/read` | Notification owner | Mark notification read |
| GET | `/users` | Admin | List accounts |
| POST | `/users` | Admin | Create account |
| GET | `/reports/summary` | Admin | University totals and workflow distribution |
| GET | `/audit-logs` | Admin | Latest 200 audit events |

The importable collection is in `docs/postman_collection.json`.

## Data relationships

- A `User` can own many projects as a student, guide many projects, or review many as a panel member.
- A `Project` references its student, guide, panel members, and rubric; embeds workflow state, deadlines, grade mix, final grade, and current plagiarism status.
- A `Submission` belongs to a project and is unique per `(project, type, version)`; feedback comments are attached to that submission and can reference a parent comment.
- An `Evaluation` references a project, its final report submission, and a reviewer; only one evaluation per reviewer/submission is allowed.
- `PlagiarismCheck` records each manual check as immutable history while `Project.plagiarism` stores the latest value.
- `Notification` belongs to a user. `AuditLog` records workflow and grade/plagiarism events.

## Current extension points

- `server/src/services/storage.js`: local disk adapter; swap for S3/Cloudinary.
- `server/src/services/notify.js`: in-app delivery plus optional SMTP email.
- Plagiarism updates are manual records today; the `PlagiarismCheck` model and project submission references provide an integration point for a future external checker.
- Charts read live API aggregates; the UI does not rely on a separate mock dataset.
