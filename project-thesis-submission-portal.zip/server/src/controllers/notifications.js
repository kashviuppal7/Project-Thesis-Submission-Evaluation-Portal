import { Notification } from '../models/index.js';
export async function list(req,res){res.json(await Notification.find({user:req.user._id}).sort({createdAt:-1}).limit(50));}
export async function markRead(req,res){const n=await Notification.findOneAndUpdate({_id:req.params.id,user:req.user._id},{readAt:new Date()},{new:true});if(!n)return res.status(404).json({message:'Notification not found'});res.json(n);}
