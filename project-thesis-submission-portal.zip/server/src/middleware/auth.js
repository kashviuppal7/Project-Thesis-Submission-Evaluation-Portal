import jwt from 'jsonwebtoken';
import { User } from '../models/index.js';
export async function protect(req,res,next){try{const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!token) return res.status(401).json({message:'Sign in to continue'});const payload=jwt.verify(token,process.env.JWT_ACCESS_SECRET);req.user=await User.findById(payload.sub);if(!req.user||!req.user.active)return res.status(401).json({message:'Account unavailable'});next();}catch(e){res.status(401).json({message:'Invalid or expired access token'});}}
export const allow=(...roles)=>(req,res,next)=>roles.includes(req.user?.role)?next():res.status(403).json({message:'You do not have access to this action'});
